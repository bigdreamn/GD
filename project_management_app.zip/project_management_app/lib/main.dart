import 'package:flutter/material.dart';

void main() {
  runApp(const N1WorkspaceApp());
}

class N1WorkspaceApp extends StatelessWidget {
  const N1WorkspaceApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'N1 - Project & Member',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.teal),
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.teal,
          foregroundColor: Colors.white,
          elevation: 2,
        ),
      ),
      home: const DashboardScreen(),
    );
  }
}

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  // Dữ liệu mẫu (Mock Data)
  final List<Map<String, dynamic>> _projects = [
    {
      'name': 'Hệ thống Chuyến Đi Chung',
      'desc': 'Nền tảng chia sẻ và đồng bộ hành trình chuyến đi cho sinh viên.',
      'color': Colors.orange,
      'date': '18/06/2026 - 20/12/2026'
    },
    {
      'name': 'Hệ thống Quản lý Phòng học',
      'desc': 'Website theo dõi và phân bổ phòng học giảng đường.',
      'color': Colors.blue,
      'date': '01/01/2026 - 30/06/2026'
    },
  ];

  final List<Map<String, String>> _members = [
    {'name': 'Nguyễn Duy Mạnh', 'email': 'duymanh@gmail.com', 'role': 'Owner'},
    {'name': 'Trần Huy Nguyễn', 'email': 'huyng@gmail.com', 'role': 'Manager'},
    {'name': 'Lê Văn B', 'email': 'levanb@gmail.com', 'role': 'Member'},
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Workspace Nhóm N1', style: TextStyle(fontWeight: FontWeight.bold)),
        bottom: TabBar(
          controller: _tabController,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white70,
          indicatorColor: Colors.white,
          indicatorWeight: 3,
          tabs: const [
            Tab(icon: Icon(Icons.folder_special), text: 'Dự án'),
            Tab(icon: Icon(Icons.group), text: 'Thành viên'),
            Tab(icon: Icon(Icons.directions_run), text: 'Sprints'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildProjectTab(),
          _buildMemberTab(),
          _buildSprintTab(),
        ],
      ),
    );
  }

  // --- TAB 1: DỰ ÁN ---
  Widget _buildProjectTab() {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _projects.length,
        itemBuilder: (context, index) {
          final p = _projects[index];
          return Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            margin: const EdgeInsets.only(bottom: 16),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                border: Border(left: BorderSide(color: p['color'], width: 6)),
              ),
              child: ListTile(
                contentPadding: const EdgeInsets.all(16),
                title: Text(p['name'], style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                subtitle: Padding(
                  padding: const EdgeInsets.only(top: 8.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(p['desc']),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Icon(Icons.access_time, size: 16, color: Colors.grey.shade600),
                          const SizedBox(width: 4),
                          Text(p['date'], style: TextStyle(color: Colors.grey.shade600)),
                        ],
                      )
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {},
        icon: const Icon(Icons.add),
        label: const Text('Tạo Dự án'),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
      ),
    );
  }

  // --- TAB 2: THÀNH VIÊN ---
  Widget _buildMemberTab() {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: _members.length,
        separatorBuilder: (_, __) => const SizedBox(height: 10),
        itemBuilder: (context, index) {
          final m = _members[index];
          Color roleColor = m['role'] == 'Owner' ? Colors.red : (m['role'] == 'Manager' ? Colors.orange : Colors.green);
          return Card(
            elevation: 0,
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: Colors.teal.shade50,
                child: Text(m['name']!.substring(0, 1), style: const TextStyle(color: Colors.teal, fontWeight: FontWeight.bold)),
              ),
              title: Text(m['name']!, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(m['email']!),
              trailing: Chip(
                label: Text(m['role']!, style: TextStyle(color: roleColor, fontWeight: FontWeight.bold, fontSize: 12)),
                backgroundColor: roleColor.withOpacity(0.1),
                side: BorderSide.none,
              ),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {},
        icon: const Icon(Icons.person_add),
        label: const Text('Thêm TV'),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
      ),
    );
  }

  // --- TAB 3: SPRINTS ---
  Widget _buildSprintTab() {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Card(
          elevation: 0,
          color: Colors.teal.shade50,
          shape: RoundedRectangleBorder(
            side: BorderSide(color: Colors.teal.shade200),
            borderRadius: BorderRadius.circular(12),
          ),
          child: const Padding(
            padding: EdgeInsets.all(16.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Sprint 1: API & Database', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: Colors.teal)),
                    Badge(label: Text('Đang chạy'), backgroundColor: Colors.green),
                  ],
                ),
                SizedBox(height: 12),
                Text('Mục tiêu: Hoàn thiện bảng thiết kế CSDL và setup Backend ASP.NET Core cơ bản.'),
                SizedBox(height: 12),
                Row(
                  children: [
                    Icon(Icons.date_range, size: 18, color: Colors.teal),
                    SizedBox(width: 6),
                    Text('Chu kỳ 2 tuần: 18/06 - 02/07', style: TextStyle(fontWeight: FontWeight.w600)),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {},
        icon: const Icon(Icons.bolt),
        label: const Text('Tạo Sprint mới'),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
      ),
    );
  }
}